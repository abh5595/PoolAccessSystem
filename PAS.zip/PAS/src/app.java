import Controller.MainController;
import java.io.FileNotFoundException;


/**
 * 
 * @author d.mikhaylov, David Ortiz
 */
public class app {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        MainController mainController = new MainController();
        
        /*  
            Employee list (retrieved from "employees.txt" in root directory:
            empID is lastname + first 2 chars of firstname.
        
            empID = scottmi  
            password = mypass
        
            empID = shrutedw
            password = sheriff
        
            empID = squarepantssp
            password = pineapple
        
            empID = starpa
            password = rock
        
        */
    }
}

package Model;

/**
 *
 * @author d.mikhaylov
 */
public interface Person {
    String getFirstName();
    String getLastName();
    String getFullName();
}

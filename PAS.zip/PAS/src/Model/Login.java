
package Model;

/**
 *
 * @author David Ortiz
 */
public interface Login {
    public boolean verifyLogin(String empID, String password); 
}

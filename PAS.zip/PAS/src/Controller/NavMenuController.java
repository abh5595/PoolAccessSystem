/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.NavUI;
import Controller.LoginController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



/**
 *
 * @author andre
 */
public class NavMenuController {
    
    private NavUI navUI; 
    
        public NavMenuController() {
        //set up the nav menu screen
            navUI = new NavUI();
            navUI.addRegisterBtnListener(new NavMenuController.RegisterBtnListener());
            navUI.addSearchBtnListener(new NavMenuController.SearchBtnListener());
            navUI.addPoolBtnListener(new NavMenuController.PoolBtnListener());
            navUI.addReportsBtnListener(new NavMenuController.ReportsBtnListener());
        }
    
    public NavUI getNavUI() {
        return navUI;
    }

    public void setNavUI(NavUI navUI) {
        this.navUI = navUI;
    } 
    
        //navigate to the register new swimmer screen
        private class RegisterBtnListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e){
                //TODO: navigates to register new swimmer scree
                System.out.println("Register Screen");
            }
        }

        //navigate to the search screen
        private class SearchBtnListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e){
                //TODO: navigate to search screen
                System.out.println("test - Search Screen");
            }
        }

        //navigate to the pool view screen
        private class PoolBtnListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e){
                //TODO: navigate to pool screen
                System.out.println("test - Pool Screen");
            }
        }

        //navigate to the reports menu screen
        private class ReportsBtnListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e){
                //TODO: navigate to reports screen
                System.out.println("test - Reports Screen");
            }
        }

}

package Controller;

import Model.Employee;
import Model.Pool;
import View.LoginUI;
import View.NavUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;

/**
 *
 * @authors David Ortiz, Andrew Hopkins
 */
public class LoginController {
    private LoginUI loginUI;
    private Pool pool;
    
    public LoginController() throws FileNotFoundException{
        //set up the log-in screen
        loginUI = new LoginUI();
        pool = new Pool();
        loginUI.addPasswordFieldKeyPressed(keyListener);
    }

    private KeyListener keyListener = new KeyListener() {
        public void keyPressed(KeyEvent keyEvent) {
        }
        public void keyTyped(KeyEvent keyEvent) {   
        }
        public void keyReleased(KeyEvent e) {
            if(loginUI.getEmpIDField().equals("") || loginUI.getPasswordField().equals("")){
                loginUI.toggleLoginButton(false);
            }else{
                loginUI.toggleLoginButton(true);
            }
        }
        
    }; //end keyListener
   
    public void resetScreen() {
        loginUI.resetPasswordField();
        loginUI.resetEmpIDField();
        loginUI.toggleLoginButton(false);
    }
    
    public LoginUI getLoginUI() {
        return loginUI;
    }

    public Pool getPool() {
        return pool;
    }
}

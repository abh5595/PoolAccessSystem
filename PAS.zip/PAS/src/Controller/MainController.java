/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Controller.LoginController;
import Controller.NavMenuController;
import Model.Employee;
import View.LoginUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

/**
 *
 * @author Andrew Hopkins
 */
public class MainController  {
    
    private LoginController loginController;
    private NavMenuController navMenuController;
    private String password;
    private String empID;
    
    public MainController() throws FileNotFoundException {
        loginController = new LoginController();
        navMenuController = new NavMenuController();
        navMenuController.getNavUI().addLogOutBtnListener(new MainController.LogOutBtnListener());
        loginController.getLoginUI().addLoginButtonListener(new LoginButtonListener());
    }
    
    
private class LoginButtonListener implements ActionListener {    
    @Override
    public void actionPerformed(ActionEvent e) {

        empID = loginController.getLoginUI().getEmpIDField();
        password = loginController.getLoginUI().getPasswordField();

        if(empID.equals("") || password.equals("")){
            System.out.println("One of the fields are empty");
        } 
        else 
        {
            boolean isEmpId = loginController.getPool().doesEmpIdExist(empID);

            if(isEmpId){
                Employee tempEmp = loginController.getPool().findEmployee(empID);

                //navigate to main menu 
                if(tempEmp.authenticate(empID, password)) {
                    navMenuController.getNavUI().welcome(tempEmp.getFirstName());
                    navMenuController.getNavUI().setVisible(true);
                    loginController.getLoginUI().setVisible(false);

                    //TODO: register customer and reports screens are available only to those with privilages
                    if (true) {
                        navMenuController.getNavUI().toggleRegisterBtn(false);
                        navMenuController.getNavUI().toggleReportsBtn(false);
                    }
                }
                else 
                {
                    loginController.getLoginUI().setStatusLabel("Login failed, incorrect password.");
                } 

            } else {
                loginController.getLoginUI().setStatusLabel("Login failed, user does not exist."); 
            }
        }
        loginController.getLoginUI().resetPasswordField();
    } 
}// end LoginButtonListener
    
    //reset the log-in screen and make it visible again
    private class LogOutBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e){
            loginController.resetScreen();
            loginController.getLoginUI().setVisible(true);
            navMenuController.getNavUI().setVisible(false);
        }
    }
}

